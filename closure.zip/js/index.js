/* 
https://developer.mozilla.org/ru/docs/Web/JavaScript/Closures
*/

var scope = "Global";
function checkscope(o, x){
  var scope = "Local " + o;
  function f() { return scope + " " + x; }
  return f();
}
console.log(checkscope(1, 3));


var scope2 = "Global";
function checkscope2(o){
  var scope2 = "Local " + o;
  function f2(x) { return scope2 + " " + x; }
  return f2;
}
console.log(checkscope2(1)(3));


var unint = (function(j) {  
  var counter = 0;
  return function(j) { return counter++ + " " + j;};
}());
console.log(unint());
console.log(unint());
console.log(unint(8));
console.log(unint());


function makeFunc() {
  var name = "Mozilla";
  function displayName() {
    alert(name);
  }
  return displayName;
};
var myFunc = makeFunc();
myFunc();